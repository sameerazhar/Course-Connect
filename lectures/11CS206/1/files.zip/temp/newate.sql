-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ate
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('sameer','welcome');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment`
--

DROP TABLE IF EXISTS `assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment` (
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `que_path` varchar(100) DEFAULT NULL,
  `time_type` int(1) DEFAULT NULL,
  `time_period` time DEFAULT NULL,
  `marks` int(3) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`assign_id`,`course_code`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `assignment_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment`
--

LOCK TABLES `assignment` WRITE;
/*!40000 ALTER TABLE `assignment` DISABLE KEYS */;
INSERT INTO `assignment` VALUES ('week_1_1','11CS206','/ate/questionData/sem3/11CS206/week_1_1/problem.txt',1,'00:00:00',20,'2015-01-11 10:00:00','2015-03-22 16:00:00'),('week_1_1','11CS207','/ate/questionData/sem3/11CS207/week_1_1/problem.txt',1,'00:00:00',20,'2015-01-11 10:00:00','2015-03-22 16:00:00');
/*!40000 ALTER TABLE `assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batches`
--

DROP TABLE IF EXISTS `batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batches` (
  `sem` int(2) NOT NULL,
  `batch` varchar(5) NOT NULL,
  PRIMARY KEY (`sem`,`batch`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batches`
--

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `course_code` varchar(10) NOT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `sem` int(2) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES ('11CS131','Java Programming Lab',1,'Java;'),('11CS132','C Programming Lab',1,'C;'),('11CS206','Programming with C',3,'C;'),('11CS207','Data Structures with Java',3,'Java;'),('11CS256','Analysis and Design of Algorithms',4,'C;Java;'),('11CS306','Python Application Programming',5,'Python;'),('11CS356','Unix Systems Programming Lab',6,'C;'),('11CS357','Programming with C++',6,'C++;');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_reg`
--

DROP TABLE IF EXISTS `course_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_reg` (
  `usn` varchar(15) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  PRIMARY KEY (`usn`,`course_code`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `course_reg_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`),
  CONSTRAINT `course_reg_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_reg`
--

LOCK TABLES `course_reg` WRITE;
/*!40000 ALTER TABLE `course_reg` DISABLE KEYS */;
INSERT INTO `course_reg` VALUES ('1PI11CS181','11CS206'),('1PI11CS181','11CS207');
/*!40000 ALTER TABLE `course_reg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_time`
--

DROP TABLE IF EXISTS `exam_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_time` (
  `course_code` varchar(10) NOT NULL,
  `assign_id` varchar(20) NOT NULL,
  `batch` varchar(5) NOT NULL DEFAULT '',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`course_code`,`assign_id`,`batch`),
  KEY `assign_id` (`assign_id`),
  CONSTRAINT `exam_time_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`),
  CONSTRAINT `exam_time_ibfk_2` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_time`
--

LOCK TABLES `exam_time` WRITE;
/*!40000 ALTER TABLE `exam_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `username` varchar(20) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES ('sameer','Syed Sameer Azhar','welcome'),('shubham','Shubham Agrawal','welcome');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty_course`
--

DROP TABLE IF EXISTS `faculty_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty_course` (
  `username` varchar(20) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  PRIMARY KEY (`username`,`course_code`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `faculty_course_ibfk_1` FOREIGN KEY (`username`) REFERENCES `faculty` (`username`),
  CONSTRAINT `faculty_course_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty_course`
--

LOCK TABLES `faculty_course` WRITE;
/*!40000 ALTER TABLE `faculty_course` DISABLE KEYS */;
INSERT INTO `faculty_course` VALUES ('sameer','11CS131'),('sameer','11CS132'),('sameer','11CS206'),('sameer','11CS306'),('sameer','11CS357');
/*!40000 ALTER TABLE `faculty_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lab_time`
--

DROP TABLE IF EXISTS `lab_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lab_time` (
  `course_code` varchar(10) NOT NULL,
  `assign_id` varchar(20) NOT NULL,
  `batch` varchar(5) NOT NULL DEFAULT '',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`course_code`,`assign_id`,`batch`),
  KEY `assign_id` (`assign_id`),
  CONSTRAINT `lab_time_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`),
  CONSTRAINT `lab_time_ibfk_2` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lab_time`
--

LOCK TABLES `lab_time` WRITE;
/*!40000 ALTER TABLE `lab_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `lab_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program` (
  `usn` varchar(15) NOT NULL,
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL DEFAULT '',
  `file_path` varchar(100) NOT NULL,
  `marks` int(3) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `files` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`usn`,`assign_id`,`course_code`),
  KEY `course_code` (`course_code`),
  KEY `assign_id` (`assign_id`),
  CONSTRAINT `program_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`),
  CONSTRAINT `program_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`),
  CONSTRAINT `program_ibfk_3` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program`
--

LOCK TABLES `program` WRITE;
/*!40000 ALTER TABLE `program` DISABLE KEYS */;
INSERT INTO `program` VALUES ('1PI11CS181','week_1_1','11CS206','/ate/studentData/sem3/1PI11CS181/11CS206/week_1_1/',0,1,'main.c;'),('1PI11CS181','week_1_1','11CS207','/ate/studentData/sem3/1PI11CS181/11CS207/week_1_1/',0,1,'Test.java;Node.java;');
/*!40000 ALTER TABLE `program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_option`
--

DROP TABLE IF EXISTS `question_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_option` (
  `qstn_id` int(11) NOT NULL DEFAULT '0',
  `option_no` int(11) NOT NULL DEFAULT '0',
  `ques_option` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`qstn_id`,`option_no`),
  CONSTRAINT `question_option_ibfk_1` FOREIGN KEY (`qstn_id`) REFERENCES `quiz_qstn_repository` (`qstn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_option`
--

LOCK TABLES `question_option` WRITE;
/*!40000 ALTER TABLE `question_option` DISABLE KEYS */;
INSERT INTO `question_option` VALUES (81,1,'rem = 3.14 % 2.1'),(81,2,'rem = modf(3.14, 2.1'),(81,3,'rem = fmod(3.14, 2.1'),(81,4,'Remainder cannot be obtain in floating point division'),(82,1,'Internal and Externa'),(82,2,'External, Internal and None'),(82,3,'External and None'),(82,4,'Internal'),(83,1,'* (asterisk)'),(83,2,'| (pipeline)'),(83,3,'- (hyphen)'),(83,4,'_ (underscore)'),(84,1,'ceil(1.66)'),(84,2,'floor(1.66)'),(84,3,'roundup(1.66)'),(84,4,'roundto(1.66'),(85,1,'reprentation of null pointer'),(85,2,'Representation of void pointer'),(85,3,'Error'),(85,4,'None of above'),(86,1,'switch'),(86,2,'goto'),(86,3,'go back'),(86,4,'return'),(87,1,'The element will be set to 0.'),(87,2,'The compiler would report an error.'),(87,3,'The program may crash if some important data gets overwritten.'),(87,4,'The array size would appropriately grow.'),(88,1,'Value of elements in array'),(88,2,'First element of the array'),(88,3,'Base address of the array'),(88,4,'Address of the last element of array'),(89,1,'memory.h'),(89,2,'stdlib.h'),(89,3,'string.h'),(89,4,'dos.h'),(90,1,'dealloc();'),(90,2,'malloc(variable_name, 0)'),(90,3,'free();'),(90,4,'memalloc(variable_name, 0)'),(91,1,'malloc()Â andÂ memalloc()'),(91,2,'alloc()Â andÂ memalloc()'),(91,3,'malloc()Â andÂ calloc()'),(91,4,'memalloc()Â andÂ faralloc()'),(92,1,'strinit()'),(92,2,'strnset()'),(92,3,'strset()'),(92,4,'strcset()'),(93,1,'-1'),(93,2,'1'),(93,4,'yes'),(94,1,'printf(\"\n\");'),(94,2,'echo \"\\n\";'),(94,4,'printf(\"\\n\");'),(95,1,'strnstr()'),(95,2,'laststr()'),(95,3,'strrchr()'),(95,4,'strstr()'),(96,1,'strchr()'),(96,2,'strrchr()'),(96,3,'strstr()'),(96,4,'strnset()'),(97,1,'printf();'),(97,2,'scanf();'),(97,3,'gets();'),(97,4,'puts();'),(98,1,'/ + * -'),(98,2,'* - / +'),(98,3,'/ * + -'),(98,4,'+ - / *'),(99,1,'a>b ? c=30 : c=40;'),(99,2,'a>b ? c=30;'),(99,3,'max = a>b ? a>c?a:c:b>c?b:c'),(99,4,'return (a>b)?(a:b)'),(100,1,'!'),(100,2,'sizeof'),(100,3,'~'),(100,4,'&&');
/*!40000 ALTER TABLE `question_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(10) DEFAULT NULL,
  `quiz_name` varchar(100) DEFAULT NULL,
  `enable` tinyint(4) DEFAULT NULL,
  `time_period` int(4) DEFAULT NULL,
  `question_order` varchar(700) DEFAULT NULL,
  PRIMARY KEY (`quiz_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
INSERT INTO `quiz` VALUES (11,'11CS206','Quiz1',1,60,'95,97,93,92,96,94');
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_qstn_repository`
--

DROP TABLE IF EXISTS `quiz_qstn_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_qstn_repository` (
  `qstn_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(10) DEFAULT NULL,
  `qstn_summary` varchar(100) DEFAULT NULL,
  `question` varchar(1000) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `difficulty` int(11) DEFAULT NULL,
  PRIMARY KEY (`qstn_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `quiz_qstn_repository_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_qstn_repository`
--

LOCK TABLES `quiz_qstn_repository` WRITE;
/*!40000 ALTER TABLE `quiz_qstn_repository` DISABLE KEYS */;
INSERT INTO `quiz_qstn_repository` VALUES (81,'11CS206','','Which of the following statements should be used to obtain a remainder after dividing 3.14 by 2.1 ?','3',1),(82,'11CS206','','what are the type of linkages','2',2),(83,'11CS206','','Which of the following special symbol allowed in a variable name','4',3),(84,'11CS206','','How would you round off a value from 1.66 to 2.0?','1',1),(85,'11CS206','','','1',2),(86,'11CS206','c/functions','The keyword used to transfer control from a function back to the calling function is','1',2),(87,'11CS206','c/arrays','What will happen if in a C program you assign a value to an array element whose subscript exceeds the size of array?','3',1),(88,'11CS206','c/arrays','n C, if you pass an array as an argument to a function, what actually gets passed?','3',3),(89,'11CS206','c/memory allocation','Which header file should be included to use functions likeÂ malloc()Â andÂ calloc()?','2',2),(90,'11CS206','c/memory allocation','What function should be used to free the memory allocated byÂ calloc()Â ?','3',2),(91,'11CS206','c/memory allocation','pecify the 2 library functions to dynamically allocate memory?','3',3),(92,'11CS206','c/strings','Which of the following function sets first n characters of a string to a given character?','2',1),(93,'11CS206','c/strings','If the two strings are identical, thenÂ strcmp()Â function returns','3',2),(94,'11CS206','c/strings','How will you print \n on the screen?','4',2),(95,'11CS206','c/strings','The library function used to find the last occurrence of a character in a string is','3',1),(96,'11CS206','c/strings','Which of the following function is used to find the first occurrence of a given string in another string?','3',2),(97,'11CS206','c/strings','Which of the following function is more appropriate for reading in a multi-word string?','3',1),(98,'11CS206','c/expression','Which of the following correctly shows the hierarchy of arithmetic operations in C?','3',2),(99,'11CS206','c/expression','Which of the following is the correct usage of conditional operators used in C?','3',1),(100,'11CS206','c/expression','Which of the following are unary operators in C?','1,2,3',1);
/*!40000 ALTER TABLE `quiz_qstn_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_student`
--

DROP TABLE IF EXISTS `quiz_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_student` (
  `usn` varchar(15) NOT NULL DEFAULT '',
  `quiz_id` int(11) NOT NULL DEFAULT '0',
  `started` int(11) DEFAULT NULL,
  `elapsed_time` int(4) DEFAULT NULL,
  `attempted_answers` varchar(500) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  PRIMARY KEY (`usn`,`quiz_id`),
  KEY `quiz_id` (`quiz_id`),
  CONSTRAINT `quiz_student_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`),
  CONSTRAINT `quiz_student_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_student`
--

LOCK TABLES `quiz_student` WRITE;
/*!40000 ALTER TABLE `quiz_student` DISABLE KEYS */;
INSERT INTO `quiz_student` VALUES ('1PI11CS181',11,0,0,'',0);
/*!40000 ALTER TABLE `quiz_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `usn` varchar(15) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sem` int(2) DEFAULT NULL,
  `password` varchar(32) NOT NULL,
  `batch` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`usn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('1PI11CS181','Syed Sameer Azhar',3,'welcome','C1');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_case`
--

DROP TABLE IF EXISTS `test_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_case` (
  `test_case_id` int(10) NOT NULL AUTO_INCREMENT,
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `input_path` varchar(100) DEFAULT NULL,
  `output_path` varchar(100) DEFAULT NULL,
  `perc_marks` int(3) DEFAULT NULL,
  PRIMARY KEY (`test_case_id`,`assign_id`,`course_code`),
  KEY `assign_id` (`assign_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `test_case_ibfk_1` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`),
  CONSTRAINT `test_case_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_case`
--

LOCK TABLES `test_case` WRITE;
/*!40000 ALTER TABLE `test_case` DISABLE KEYS */;
INSERT INTO `test_case` VALUES (1,'week_1_1','11CS206','','',100),(2,'week_1_1','11CS207','','',100);
/*!40000 ALTER TABLE `test_case` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-19 18:38:55
