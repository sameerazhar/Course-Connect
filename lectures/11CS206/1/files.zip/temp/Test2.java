class Test2
{
	public void display()
	{
		System.out.println("Test2");
	}
}
