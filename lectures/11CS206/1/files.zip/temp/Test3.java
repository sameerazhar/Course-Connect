class Test3
{
	public void display()
	{
		System.out.println("Test3");
		Test2 t = new Test2();
		t.display();
	}
}
