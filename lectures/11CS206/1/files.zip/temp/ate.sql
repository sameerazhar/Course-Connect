-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ate
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('sameer','welcome');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment`
--

DROP TABLE IF EXISTS `assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment` (
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `que_path` varchar(100) DEFAULT NULL,
  `time_type` int(1) DEFAULT NULL,
  `time_period` time DEFAULT NULL,
  `marks` int(3) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`assign_id`,`course_code`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `assignment_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment`
--

LOCK TABLES `assignment` WRITE;
/*!40000 ALTER TABLE `assignment` DISABLE KEYS */;
INSERT INTO `assignment` VALUES ('week_1_1','11CS206','/ate/questionData/sem3/11CS206/week_1_1/problem.txt',1,'00:00:00',20,'2015-01-11 10:00:00','2015-03-22 16:00:00');
/*!40000 ALTER TABLE `assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batches`
--

DROP TABLE IF EXISTS `batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batches` (
  `sem` int(2) NOT NULL,
  `batch` varchar(5) NOT NULL,
  PRIMARY KEY (`sem`,`batch`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batches`
--

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `course_code` varchar(10) NOT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `sem` int(2) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES ('11CS131','Java Programming Lab',1,'Java;'),('11CS132','C Programming Lab',1,'C;'),('11CS206','Programming with C',3,'C;'),('11CS207','Data Structures with Java',3,'Java;'),('11CS256','Analysis and Design of Algorithms',4,'C;Java;'),('11CS306','Python Application Programming',5,'Python;'),('11CS356','Unix Systems Programming Lab',6,'C;'),('11CS357','Programming with C++',6,'C++;');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_reg`
--

DROP TABLE IF EXISTS `course_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_reg` (
  `usn` varchar(15) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  PRIMARY KEY (`usn`,`course_code`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `course_reg_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`),
  CONSTRAINT `course_reg_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_reg`
--

LOCK TABLES `course_reg` WRITE;
/*!40000 ALTER TABLE `course_reg` DISABLE KEYS */;
INSERT INTO `course_reg` VALUES ('1PI11CS181','11CS206'),('1PI11CS181','11CS207');
/*!40000 ALTER TABLE `course_reg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_time`
--

DROP TABLE IF EXISTS `exam_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_time` (
  `course_code` varchar(10) NOT NULL,
  `assign_id` varchar(20) NOT NULL,
  `batch` varchar(5) NOT NULL DEFAULT '',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`course_code`,`assign_id`,`batch`),
  KEY `assign_id` (`assign_id`),
  CONSTRAINT `exam_time_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`),
  CONSTRAINT `exam_time_ibfk_2` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_time`
--

LOCK TABLES `exam_time` WRITE;
/*!40000 ALTER TABLE `exam_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `username` varchar(20) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES ('sameer','Syed Sameer Azhar','welcome'),('shubham','Shubham Agrawal','welcome');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty_course`
--

DROP TABLE IF EXISTS `faculty_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty_course` (
  `username` varchar(20) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  PRIMARY KEY (`username`,`course_code`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `faculty_course_ibfk_1` FOREIGN KEY (`username`) REFERENCES `faculty` (`username`),
  CONSTRAINT `faculty_course_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty_course`
--

LOCK TABLES `faculty_course` WRITE;
/*!40000 ALTER TABLE `faculty_course` DISABLE KEYS */;
INSERT INTO `faculty_course` VALUES ('sameer','11CS131'),('sameer','11CS132'),('sameer','11CS206'),('sameer','11CS306'),('sameer','11CS357');
/*!40000 ALTER TABLE `faculty_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lab_time`
--

DROP TABLE IF EXISTS `lab_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lab_time` (
  `course_code` varchar(10) NOT NULL,
  `assign_id` varchar(20) NOT NULL,
  `batch` varchar(5) NOT NULL DEFAULT '',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`course_code`,`assign_id`,`batch`),
  KEY `assign_id` (`assign_id`),
  CONSTRAINT `lab_time_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`),
  CONSTRAINT `lab_time_ibfk_2` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lab_time`
--

LOCK TABLES `lab_time` WRITE;
/*!40000 ALTER TABLE `lab_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `lab_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program` (
  `usn` varchar(15) NOT NULL,
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL DEFAULT '',
  `file_path` varchar(100) NOT NULL,
  `marks` int(3) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `files` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`usn`,`assign_id`,`course_code`),
  KEY `course_code` (`course_code`),
  KEY `assign_id` (`assign_id`),
  CONSTRAINT `program_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`),
  CONSTRAINT `program_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`),
  CONSTRAINT `program_ibfk_3` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program`
--

LOCK TABLES `program` WRITE;
/*!40000 ALTER TABLE `program` DISABLE KEYS */;
INSERT INTO `program` VALUES ('1PI11CS181','week_1_1','11CS206','/ate/studentData/sem3/1PI11CS181/11CS206/week_1_1/',0,1,'main.c;func.c;');
/*!40000 ALTER TABLE `program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_option`
--

DROP TABLE IF EXISTS `question_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_option` (
  `qstn_id` int(11) NOT NULL DEFAULT '0',
  `option_no` int(11) NOT NULL DEFAULT '0',
  `ques_option` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`qstn_id`,`option_no`),
  CONSTRAINT `question_option_ibfk_1` FOREIGN KEY (`qstn_id`) REFERENCES `quiz_qstn_repository` (`qstn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_option`
--

LOCK TABLES `question_option` WRITE;
/*!40000 ALTER TABLE `question_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(10) DEFAULT NULL,
  `quiz_name` varchar(100) DEFAULT NULL,
  `enable` tinyint(4) DEFAULT NULL,
  `time_period` time DEFAULT NULL,
  `question_order` varchar(700) DEFAULT NULL,
  PRIMARY KEY (`quiz_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_qstn_repository`
--

DROP TABLE IF EXISTS `quiz_qstn_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_qstn_repository` (
  `qstn_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(10) DEFAULT NULL,
  `qstn_summary` varchar(100) DEFAULT NULL,
  `question` varchar(1000) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `difficulty` int(11) DEFAULT NULL,
  PRIMARY KEY (`qstn_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `quiz_qstn_repository_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_qstn_repository`
--

LOCK TABLES `quiz_qstn_repository` WRITE;
/*!40000 ALTER TABLE `quiz_qstn_repository` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_qstn_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_student`
--

DROP TABLE IF EXISTS `quiz_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_student` (
  `usn` varchar(15) NOT NULL DEFAULT '',
  `quiz_id` int(11) NOT NULL DEFAULT '0',
  `started` int(11) DEFAULT NULL,
  `elapsed_time` time DEFAULT NULL,
  `attempted_answers` varchar(500) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  PRIMARY KEY (`usn`,`quiz_id`),
  KEY `quiz_id` (`quiz_id`),
  CONSTRAINT `quiz_student_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`),
  CONSTRAINT `quiz_student_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_student`
--

LOCK TABLES `quiz_student` WRITE;
/*!40000 ALTER TABLE `quiz_student` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `usn` varchar(15) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sem` int(2) DEFAULT NULL,
  `password` varchar(32) NOT NULL,
  `batch` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`usn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('1PI11CS181','Syed Sameer Azhar',3,'welcome','C1');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_case`
--

DROP TABLE IF EXISTS `test_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_case` (
  `test_case_id` int(10) NOT NULL AUTO_INCREMENT,
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `input_path` varchar(100) DEFAULT NULL,
  `output_path` varchar(100) DEFAULT NULL,
  `perc_marks` int(3) DEFAULT NULL,
  PRIMARY KEY (`test_case_id`,`assign_id`,`course_code`),
  KEY `assign_id` (`assign_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `test_case_ibfk_1` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`),
  CONSTRAINT `test_case_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_case`
--

LOCK TABLES `test_case` WRITE;
/*!40000 ALTER TABLE `test_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_case` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-15 19:43:43
