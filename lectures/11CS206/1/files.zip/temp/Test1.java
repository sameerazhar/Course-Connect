public class Test1
{
	public static void main(String [] args)
	{
		Test2 t2 = new Test2();
		t2.display();
		Test3 t3 = new Test3();
		t3.display();
		System.out.println("OK");
	}
}
