f = "Test.java"

print(f.split(f, "."));
