#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<fcntl.h>


void change_permission(char *);

int main(int argc, char **argv)
{
	if( argc < 2 )
	{
		printf("Give a file name as command line argument\n");
		exit(0);
	}
	change_permission(argv[1]);
}


void change_permission(char *file)
{
	struct stat buf;
	if( (stat( file, &buf )) < 0 )
	{
		perror("");
		exit(0);
	}

	if( S_ISDIR( buf.st_mode ) )
	{
		DIR *dp = opendir(file);
		struct dirent *d_buf;
		struct stat b;
		if( (chmod( file, ( S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH ) )) < 0 )
		{
			perror("");
			exit(0);
		}
		char wd[200];
		getcwd( wd, 200 );
		chdir(file);
		while( (d_buf = readdir(dp)) != NULL )
		{
			if( strcmp( d_buf->d_name, ".") == 0 || strcmp( d_buf->d_name, "..") == 0 )
			{
				continue;
			}
			if( (stat( d_buf->d_name, &b )) < 0 )
			{
				perror("");
				exit(0);
			}
			if( S_ISDIR( b.st_mode ) )
			{
				change_permission( d_buf->d_name );
			}
			else
			{
				int fd = open( d_buf->d_name, O_RDONLY );
				if( (fchmod( fd, ( S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH ) )) < 0 )
				{
					perror("");
					exit(0);
				}
				close(fd);
			}
		}
		chdir(wd);
		closedir(dp);
	}
	else
	{
		int fd = open( file, O_RDONLY );
		if( (fchmod( fd, ( S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH ) )) < 0 )
		{
			perror("");
			exit(0);
		}
		close(fd);
	}
}
