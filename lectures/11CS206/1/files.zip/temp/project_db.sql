-- MySQL dump 10.13  Distrib 5.5.40, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: project_db
-- ------------------------------------------------------
-- Server version	5.5.40-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('sameer','welcome');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment`
--

DROP TABLE IF EXISTS `assignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment` (
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `que_path` varchar(50) NOT NULL,
  `time_type` int(1) NOT NULL,
  `time_period` time DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `marks` int(3) DEFAULT NULL,
  PRIMARY KEY (`assign_id`,`course_code`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `assignment_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment`
--

LOCK TABLES `assignment` WRITE;
/*!40000 ALTER TABLE `assignment` DISABLE KEYS */;
INSERT INTO `assignment` VALUES ('week_1_1','11CS351','/ate/question/sem6/11CS351/week_1_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_1_1','11CS352','/ate/question/sem6/11CS352/week_1_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_1_1','11CS404','/ate/question/sem7/11CS404/week_1_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_1_1','11CS405','/ate/question/sem7/11CS405/week_1_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_1_2','11CS351','/ate/question/sem6/11CS351/week_1_2.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_2_1','11CS351','/ate/question/sem6/11CS351/week_2_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_2_1','11CS352','/ate/question/sem6/11CS352/week_2_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_2_1','11CS404','/ate/question/sem7/11CS404/week_2_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_2_1','11CS405','/ate/question/sem7/11CS405/week_2_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_2_2','11CS404','/ate/question/sem7/11CS404/week_2_2.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_2_2','11CS405','/ate/question/sem7/11CS405/week_2_2.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_3_1','11CS404','/ate/question/sem7/11CS404/week_3_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_3_1','11CS405','/ate/question/sem7/11CS405/week_3_1.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20),('week_3_2','11CS404','/ate/question/sem7/11CS404/week_3_2.txt',1,'00:00:00','2015-01-11 10:00:00','2015-03-22 16:00:00',20);
/*!40000 ALTER TABLE `assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batches`
--

DROP TABLE IF EXISTS `batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batches` (
  `sem` int(1) NOT NULL,
  `batch` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`sem`,`batch`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batches`
--

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
INSERT INTO `batches` VALUES (6,'c1'),(6,'c2'),(7,'C1'),(7,'c2');
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `course_code` varchar(10) NOT NULL,
  `course_name` varchar(50) DEFAULT NULL,
  `sem` int(1) NOT NULL,
  `password` varchar(10) NOT NULL,
  `language` varchar(50) NOT NULL,
  PRIMARY KEY (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES ('11CS301','Python Application Programming',5,'welcome','Python;'),('11CS351','Unix Programming',6,'welcome','C;'),('11CS352','C++ Programming',6,'welcome','C++;'),('11CS404','C Programming Lab',7,'welcome','C;C++;'),('11CS405','Java Programming Lab',7,'welcome','Java;'),('11CS406','Analysis and Design of Algorithms Lab',7,'welcome','Java;');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_reg`
--

DROP TABLE IF EXISTS `course_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_reg` (
  `course_code` varchar(10) NOT NULL,
  `usn` varchar(15) NOT NULL,
  PRIMARY KEY (`course_code`,`usn`),
  KEY `usn` (`usn`),
  CONSTRAINT `course_reg_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`),
  CONSTRAINT `course_reg_ibfk_2` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_reg`
--

LOCK TABLES `course_reg` WRITE;
/*!40000 ALTER TABLE `course_reg` DISABLE KEYS */;
INSERT INTO `course_reg` VALUES ('11CS351','1PI11CS169'),('11CS352','1PI11CS169'),('11CS404','1PI11CS181'),('11CS405','1PI11CS181'),('11CS406','1PI11CS181');
/*!40000 ALTER TABLE `course_reg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_time`
--

DROP TABLE IF EXISTS `exam_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_time` (
  `course_code` varchar(10) NOT NULL DEFAULT '',
  `assign_id` varchar(20) NOT NULL DEFAULT '',
  `batch` varchar(5) NOT NULL DEFAULT '',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`course_code`,`assign_id`,`batch`),
  KEY `assign_id` (`assign_id`),
  CONSTRAINT `exam_time_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `assignment` (`course_code`),
  CONSTRAINT `exam_time_ibfk_2` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_time`
--

LOCK TABLES `exam_time` WRITE;
/*!40000 ALTER TABLE `exam_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lab_time`
--

DROP TABLE IF EXISTS `lab_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lab_time` (
  `course_code` varchar(10) NOT NULL DEFAULT '',
  `assign_id` varchar(20) NOT NULL DEFAULT '',
  `batch` varchar(5) NOT NULL DEFAULT '',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`course_code`,`assign_id`,`batch`),
  KEY `assign_id` (`assign_id`),
  CONSTRAINT `lab_time_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `assignment` (`course_code`),
  CONSTRAINT `lab_time_ibfk_2` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lab_time`
--

LOCK TABLES `lab_time` WRITE;
/*!40000 ALTER TABLE `lab_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `lab_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program` (
  `usn` varchar(15) NOT NULL,
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `file_path` varchar(50) NOT NULL,
  `marks` int(3) DEFAULT NULL,
  `status` int(1) NOT NULL,
  `files` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`usn`,`assign_id`,`course_code`),
  KEY `assign_id` (`assign_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `program_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`),
  CONSTRAINT `program_ibfk_2` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`),
  CONSTRAINT `program_ibfk_3` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program`
--

LOCK TABLES `program` WRITE;
/*!40000 ALTER TABLE `program` DISABLE KEYS */;
INSERT INTO `program` VALUES ('1PI11CS169','week_1_1','11CS351','student/sem6/1PI11CS169/11CS351/week_1_1/',0,1,'func.c;'),('1PI11CS169','week_1_1','11CS352','student/sem6/1PI11CS169/11CS352/week_1_1/',0,1,''),('1PI11CS169','week_1_2','11CS351','student/sem6/1PI11CS169/11CS351/week_1_2/',0,0,''),('1PI11CS169','week_2_1','11CS351','student/sem6/1PI11CS169/11CS351/week_2_1/',0,1,'main.c;'),('1PI11CS169','week_2_1','11CS352','student/sem6/1PI11CS169/11CS352/week_2_1/',0,0,''),('1PI11CS181','week_2_1','11CS404','student/sem7/1PI11CS181/11CS404/week_2_1/',0,1,'func.c;'),('1PI11CS181','week_2_2','11CS404','student/sem7/1PI11CS181/11CS404/week_2_2/',0,0,''),('1PI11CS181','week_3_1','11CS404','student/sem7/1PI11CS181/11CS404/week_3_1/',0,0,''),('1PI11CS181','week_3_1','11CS405','student/sem7/1PI11CS181/11CS405/week_3_1/',0,0,'');
/*!40000 ALTER TABLE `program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_option`
--

DROP TABLE IF EXISTS `question_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question_option` (
  `qstn_id` int(11) NOT NULL DEFAULT '0',
  `option_no` int(11) NOT NULL DEFAULT '0',
  `ques_option` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`qstn_id`,`option_no`),
  CONSTRAINT `question_option_ibfk_1` FOREIGN KEY (`qstn_id`) REFERENCES `quiz_qstn_repository` (`qstn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_option`
--

LOCK TABLES `question_option` WRITE;
/*!40000 ALTER TABLE `question_option` DISABLE KEYS */;
INSERT INTO `question_option` VALUES (4,1,'a'),(4,2,'b'),(4,3,'c'),(4,4,'d'),(5,1,'aa'),(5,2,'bb'),(5,3,'cc'),(6,1,'aaa'),(6,2,'bbb'),(6,3,'ccc'),(6,4,'ddd'),(6,5,'eee'),(7,1,'a'),(7,2,'b'),(7,3,'c'),(7,4,'d'),(8,1,'aa'),(8,2,'bb'),(8,3,'cc'),(9,1,'aaa'),(9,2,'bbb'),(9,3,'ccc'),(9,4,'ddd'),(9,5,'eee'),(10,1,'a'),(10,2,'b'),(10,3,'c'),(10,4,'d'),(11,1,'aa'),(11,2,'bb'),(11,3,'cc'),(12,1,'aaa'),(12,2,'bbb'),(12,3,'ccc'),(12,4,'ddd'),(12,5,'eee'),(13,1,'a'),(13,2,'b'),(13,3,'c'),(13,4,'d'),(14,1,'aa'),(14,2,'bb'),(14,3,'cc'),(15,1,'aaa'),(15,2,'bbb'),(15,3,'ccc'),(15,4,'ddd'),(15,5,'eee'),(16,1,'a'),(16,2,'b'),(16,3,'c'),(16,4,'d'),(17,1,'aa'),(17,2,'bb'),(17,3,'cc'),(18,1,'aaa'),(18,2,'bbb'),(18,3,'ccc'),(18,4,'ddd'),(18,5,'eee');
/*!40000 ALTER TABLE `question_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(10) DEFAULT NULL,
  `quiz_name` varchar(100) DEFAULT NULL,
  `enable` tinyint(4) DEFAULT NULL,
  `time_period` time DEFAULT NULL,
  `question_order` varchar(700) DEFAULT NULL,
  PRIMARY KEY (`quiz_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_qstn_repository`
--

DROP TABLE IF EXISTS `quiz_qstn_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_qstn_repository` (
  `qstn_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(10) DEFAULT NULL,
  `qstn_summary` varchar(100) DEFAULT NULL,
  `question` varchar(1000) DEFAULT NULL,
  `correct_answer` varchar(10) DEFAULT NULL,
  `difficulty` int(11) DEFAULT NULL,
  PRIMARY KEY (`qstn_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `quiz_qstn_repository_ibfk_1` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_qstn_repository`
--

LOCK TABLES `quiz_qstn_repository` WRITE;
/*!40000 ALTER TABLE `quiz_qstn_repository` DISABLE KEYS */;
INSERT INTO `quiz_qstn_repository` VALUES (4,'11CS404','tree/binarytree','what is xyz','2,3',1),(5,'11CS404','tree/binarytree/BST','how','1,3',2),(6,'11CS404','list/linkedlist','why','1,3,5',3),(7,'11CS404','tree/binarytree','qwerty','2,3',2),(8,'11CS404','tree/binarytree/BST','asdfh','1,3',1),(9,'11CS404','list/linkedlist','zxcvb','1,3,5',1),(10,'11CS404','tree/binarytree','poiu','2,3',2),(11,'11CS404','tree/binarytree/BST','lkjhg','1,3',1),(12,'11CS404','list/linkedlist','mnbvc','1,3,5',2),(13,'11CS404','tree/binarytree','plmnjoy','2,3',3),(14,'11CS404','tree/binarytree/BST','gydjnkj','1,3',3),(15,'11CS404','list/linkedlist','sdscsdd','1,3,5',2),(16,'11CS404','tree/binarytree','dfbfgbdvds','2,3',3),(17,'11CS404','tree/binarytree/BST','sdvdfbfdbfdb','1,3',3),(18,'11CS404','list/linkedlist','sdvdsvasvsdbv','1,3,5',1);
/*!40000 ALTER TABLE `quiz_qstn_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_student`
--

DROP TABLE IF EXISTS `quiz_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quiz_student` (
  `usn` varchar(15) NOT NULL DEFAULT '',
  `quiz_id` int(11) NOT NULL DEFAULT '0',
  `started` int(11) DEFAULT NULL,
  `elapsed_time` time DEFAULT NULL,
  `attempted_answers` varchar(500) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  PRIMARY KEY (`usn`,`quiz_id`),
  KEY `quiz_id` (`quiz_id`),
  CONSTRAINT `quiz_student_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`),
  CONSTRAINT `quiz_student_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_student`
--

LOCK TABLES `quiz_student` WRITE;
/*!40000 ALTER TABLE `quiz_student` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `usn` varchar(15) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `sem` int(1) NOT NULL,
  `password` varchar(10) NOT NULL,
  `batch` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`usn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('1PI11CS169','Shubham',6,'welcome','c2'),('1PI11CS181','Sameer',7,'welcome','c1');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_case`
--

DROP TABLE IF EXISTS `test_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_case` (
  `assign_id` varchar(20) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `test_case_id` varchar(10) NOT NULL,
  `input` varchar(200) DEFAULT NULL,
  `output` varchar(500) DEFAULT NULL,
  `perc_marks` int(3) DEFAULT NULL,
  PRIMARY KEY (`assign_id`,`course_code`,`test_case_id`),
  KEY `course_code` (`course_code`),
  CONSTRAINT `test_case_ibfk_1` FOREIGN KEY (`assign_id`) REFERENCES `assignment` (`assign_id`),
  CONSTRAINT `test_case_ibfk_2` FOREIGN KEY (`course_code`) REFERENCES `course` (`course_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_case`
--

LOCK TABLES `test_case` WRITE;
/*!40000 ALTER TABLE `test_case` DISABLE KEYS */;
INSERT INTO `test_case` VALUES ('week_1_1','11CS351','12','','Hello World',100),('week_1_1','11CS352','14','','Hello World',100),('week_1_1','11CS404','1','5','Hello World\n5',100),('week_1_1','11CS405','5','5','Hello World\n5',100),('week_1_2','11CS351','13','','Hello World',100),('week_2_1','11CS351','11','','Hello World',100),('week_2_1','11CS352','14','','Hello World',100),('week_2_1','11CS404','10','2000','Hello World\n2000',100),('week_2_1','11CS404','2','5','Hello World\n5',100),('week_2_1','11CS404','9','5','Hello World\n5',100),('week_2_1','11CS405','6','5','Hello World\n5',100),('week_2_2','11CS404','3','5','Hello World\n5',100),('week_2_2','11CS404','9','5','Hello World\n5',100),('week_2_2','11CS405','7','5','Hello World\n5',100),('week_3_1','11CS404','4','5','Hello World\n5',100),('week_3_1','11CS405','8','5','Hello World\n5',100);
/*!40000 ALTER TABLE `test_case` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-10 23:18:18
